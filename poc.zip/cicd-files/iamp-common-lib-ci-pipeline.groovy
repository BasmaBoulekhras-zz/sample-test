@Library('jenkins-pipeline-library')
import hudson.model.*
pipeline {
	agent { node { label 'maven' } }
	stages {
		stage('Init Pipeline') {
            steps {
                parallel (
                    "Parse WebHook": {
                        initPipeline()
                    },
                    "Init CICD": {
                        initCICD()
                    }
                )
            }
        }
        
        stage ("Checkout & Build") {
            steps {
                gitCheckout repoURL: repoURL, branch: branch, directory: appName, credentialsId: 'jenkins-gogs'
                
                dir("${appName}") {
                    mavenBuild()
                }
            }
        }
        
        stage('Unit Testing') {
            steps {
                dir("${appName}") {
                    mavenTest()
                }
            }
        }
        
        stage('Sonar Scan') {
            steps {
                dir("${appName}") {
                    mavenSonarScan()
                }
            }
        }
		
		stage('OWASP Scan') {
            steps {
                dir("${appName}") {
                    mavenOwaspScan()
                }
            }
        }
        
        stage('Push Artifacts') {
            when {
                expression { return branch == "develop" }
            }
            steps {
                dir("${appName}") {
                    mavenDeploy()
                }
            }
        }
	}
	
	post('Publish Results') {
        always {
            slackBuildResult()
        }
    }
}