#!/usr/bin/groovy

def call() {
	
	sh "mvn test"
}